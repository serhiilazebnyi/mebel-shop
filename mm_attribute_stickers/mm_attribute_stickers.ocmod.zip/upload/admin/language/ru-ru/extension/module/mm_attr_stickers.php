<?php
// Text
$_['tab_attr_stickers']   = 'Стикеры характеристик';

// Entry
$_['attribute_stickers_name']   = 'Название стикера характеристик';
$_['attribute_stickers_image']    = 'Изображение стикера характеристик';
$_['attribute_stickers_text']      = 'Текст стикера характеристик';
$_['attribute_sticker_action']      = 'Действие';
$_['attribute_stickers_sort_order']     = 'Порядок сортировки';
