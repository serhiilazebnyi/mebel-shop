<?php
// Text
$_['tab_attr_stickers']   = 'Стікери характеристик';

// Entry
$_['attribute_stickers_name']   = 'Назва стікера характеристик';
$_['attribute_stickers_image']    = 'Зображення стікера характеристик';
$_['attribute_stickers_text']      = 'Текст стікера характеристик';
$_['attribute_sticker_action']      = 'Дія';
$_['attribute_stickers_sort_order']     = 'Порядок сортування';
