<?php
// Heading
$_['heading_title']    = 'Мир Матрасов: Товар Дня';

// Text
$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Ви успішно змінили налаштування!';
$_['text_edit']        = 'Змінити налаштування Товару Дня';

// Entry
$_['entry_product']    = 'Товар';

// Help
$_['help_product']     = '(Автозаповнення)';

// Error
$_['error_permission'] = 'Увага: У вас немає прав модифікувати модуль Товару Дня!';
