<?php
// Heading
$_['heading_title'] = 'Interesting Latest';

$_['mm_interesting_latest_all'] = 'All';
$_['mm_interesting_latest_reviews'] = 'Reviews: ';
