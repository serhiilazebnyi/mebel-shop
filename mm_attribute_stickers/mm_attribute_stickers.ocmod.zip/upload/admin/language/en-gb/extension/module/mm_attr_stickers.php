<?php
// Text
$_['tab_attr_stickers']   = 'Attribute Stickers';

// Entry
$_['attribute_stickers_name']   = 'Attribute Sticker Name';
$_['attribute_stickers_image']    = 'Attribute Sticker Image';
$_['attribute_stickers_text']      = 'Attribute Sticker Text';
$_['attribute_sticker_action']      = 'Action';
$_['attribute_stickers_sort_order']     = 'Sort Order';
