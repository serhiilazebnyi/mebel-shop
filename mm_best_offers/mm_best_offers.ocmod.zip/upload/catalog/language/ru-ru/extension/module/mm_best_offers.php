<?php
// Heading
$_['heading_title'] = 'Лучшие предложения';

$_['mm_best_offers_all'] = 'Все';
$_['mm_best_offers_reviews'] = 'Отзывов: ';
