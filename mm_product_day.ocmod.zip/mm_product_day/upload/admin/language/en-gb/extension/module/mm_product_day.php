<?php
// Heading
$_['heading_title']    = 'Mir Matrasov Product of the Day';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified product of the day module!';
$_['text_edit']        = 'Edit Product of the Day Module';

// Entry
$_['entry_product']    = 'Product';

// Help
$_['help_product']     = '(Autocomplete)';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify best offers module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
