<?php
// Heading
$_['heading_title'] = 'Product of the Day';

// Entry
$_['limited_entry'] = 'Limited quantity.';
$_['just_today_entry'] = 'Offer valid only <strong>today</strong>';
