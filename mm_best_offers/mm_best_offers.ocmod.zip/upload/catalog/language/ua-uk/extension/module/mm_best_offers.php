<?php
// Heading
$_['heading_title'] = 'Кращі пропозиції';

$_['mm_best_offers_all'] = 'Інші';
$_['mm_best_offers_reviews'] = 'Відгуків: ';
