<?php
// Heading
$_['heading_title']    = 'Мир Матрасов: Товар Дня';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Вы успешно изменили настройки!';
$_['text_edit']        = 'Изменить настройки Товара Дня';

// Entry
$_['entry_product']    = 'Товар';

// Help
$_['help_product']     = '(Автозаполнение)';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав модифицировать модуль Товар Дня!';
