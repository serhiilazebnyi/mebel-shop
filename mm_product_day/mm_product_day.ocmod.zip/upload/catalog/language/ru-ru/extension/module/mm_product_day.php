<?php
// Heading
$_['heading_title'] = 'Товар Дня';

// Entry
$_['limited_entry'] = 'Ограниченное количество.';
$_['just_today_entry'] = 'Предложение действительно только <strong>сегодня</strong>';
