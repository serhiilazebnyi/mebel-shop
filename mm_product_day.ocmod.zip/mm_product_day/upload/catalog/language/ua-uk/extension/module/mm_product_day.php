<?php
// Heading
$_['heading_title'] = 'Товар Дня';

// Entry
$_['limited_entry'] = 'Обмежена кількість.';
$_['just_today_entry'] = 'Пропозиція дійсна тільки <strong>сьогодні</strong>';
