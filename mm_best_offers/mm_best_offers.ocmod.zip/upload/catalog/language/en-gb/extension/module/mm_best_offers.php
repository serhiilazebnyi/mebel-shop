<?php
// Heading
$_['heading_title'] = 'Best Offers';

$_['mm_best_offers_all'] = 'All';
$_['mm_best_offers_reviews'] = 'Reviews: ';
