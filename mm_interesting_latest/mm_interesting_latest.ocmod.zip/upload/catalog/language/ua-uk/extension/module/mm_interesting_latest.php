<?php
// Heading
$_['heading_title'] = 'Цікаві Новинки';

$_['mm_interesting_latest_reviews'] = 'Інші';
$_['mm_interesting_latest_reviews'] = 'Відгуків: ';
