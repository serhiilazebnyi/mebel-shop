<?php
// Heading
$_['heading_title'] = 'Интересные Новинки';

$_['mm_interesting_latest_all'] = 'Все';
$_['mm_interesting_latest_reviews'] = 'Отзывов: ';
